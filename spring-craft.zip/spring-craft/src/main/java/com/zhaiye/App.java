package com.zhaiye;

import com.zhaiye.framework.ZhaiyeApplicationContext;
import com.zhaiye.framework.exception.NoSuchBeanException;
import com.zhaiye.service.UserService;

/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) throws NoSuchBeanException {
        //启动Spring，扫描，创建非懒加载的单例bean
        ZhaiyeApplicationContext applicationContext = new ZhaiyeApplicationContext(AppConfig.class);

        //会创建懒加载的单例bean
        UserService userService = (UserService)applicationContext.getBean("userService");
        System.out.println(userService);

        userService.test();
    }
}
