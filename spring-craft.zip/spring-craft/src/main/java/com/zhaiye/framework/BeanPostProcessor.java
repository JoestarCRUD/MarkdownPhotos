package com.zhaiye.framework;

import com.zhaiye.framework.exception.NoSuchBeanException;

public interface BeanPostProcessor {
    void postProcessAfterInitialization(Class beanClass, Object instance) throws NoSuchBeanException, IllegalAccessException;
}
