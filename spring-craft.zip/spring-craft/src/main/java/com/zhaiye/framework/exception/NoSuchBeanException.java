package com.zhaiye.framework.exception;

public class NoSuchBeanException extends Throwable {
}
