package com.zhaiye.framework;

import com.zhaiye.framework.annotation.Autowired;
import com.zhaiye.framework.annotation.Component;
import com.zhaiye.framework.annotation.ComponentScan;
import com.zhaiye.framework.annotation.Scope;
import com.zhaiye.framework.exception.NoSuchBeanException;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.util.*;

public class ZhaiyeApplicationContext {

    private final Map<String, BeanDefinition> beanDefinitionMap = new HashMap<>();
    private final Map<String, Object> singletonObjects = new HashMap<>();
    private Set<BeanPostProcessor> beanPostProcessorSet = new HashSet<>();

    public ZhaiyeApplicationContext(Class config) {
        //模拟扫描
        scan(config);
        //创建非懒加载的单例bean
        createNonLazySingleton();
    }

    private void createNonLazySingleton() {
        for (String beanName : beanDefinitionMap.keySet()) {
            BeanDefinition beanDefinition = beanDefinitionMap.get(beanName);
            if (beanDefinition.getScope().equals("Singleton") && !beanDefinition.isLazy()) {
                //创建bean
                singletonObjects.put(beanName, createBean(beanDefinition));
            }
        }
    }

    private void scan(Class configClass) {
        if (configClass.isAnnotationPresent(ComponentScan.class)) {
            //以配置类的classLoader为基础，通过配置类的注解给出的路径开始扫描制定范围内的类
            ComponentScan componentScan = (ComponentScan) configClass.getAnnotation(ComponentScan.class);
            String path = componentScan.value().replace(".", "/");
            ClassLoader classLoader = ZhaiyeApplicationContext.class.getClassLoader();
            URL resource = classLoader.getResource(path);
            assert resource != null;
            File file = new File(resource.getFile());
            for (File f : Objects.requireNonNull(file.listFiles())) {
                if (f.getAbsolutePath().endsWith(".class")) {
                    String beanPath = f.getAbsolutePath().substring(f.getAbsolutePath().indexOf("com"), f.getAbsolutePath().indexOf(".class"));
                    beanPath = beanPath.replace("\\", ".");
                    try {
                        Class clazz = classLoader.loadClass(beanPath);
                        //如果有，说明这是一个bean，但是这里我们只需要创建非懒加载的bean
                        if (clazz.isAnnotationPresent(Component.class)) {
                            if (BeanPostProcessor.class.isAssignableFrom(clazz)) {
                                BeanPostProcessor o = (BeanPostProcessor) clazz.getDeclaredConstructor().newInstance();
                                beanPostProcessorSet.add(o);
                            }
//                            //这边就会有一系列的遍历操作，一一判断是否有各种各样的注解
                            Component component = (Component) clazz.getAnnotation(Component.class);
                            String beanName = component.value();
//                            if(clazz.isAnnotationPresent(Scope.class)){
//                                Scope scope = (com.zhaiye.framework.annotation.Scope) clazz.getAnnotation(com.zhaiye.framework.annotation.Scope.class);
//                            }else{//说明是单例的
//
//                            }
                            //这是一个bean，我们要为其生成beanDefinition
                            BeanDefinition beanDefinition = new BeanDefinition();
                            beanDefinition.setBeanClass(clazz);
                            beanDefinition.setBeanName(beanName);
                            if (clazz.isAnnotationPresent(Scope.class)) {
                                Scope scope = (Scope) clazz.getAnnotation(Scope.class);
                                String value = scope.value();
                                beanDefinition.setScope(value);
                            } else {//说明是单例的
                                beanDefinition.setScope("Singleton");
                            }
                            beanDefinitionMap.put(beanName, beanDefinition);
                        }
                    } catch (ClassNotFoundException | NoSuchMethodException | IllegalAccessException | InstantiationException | InvocationTargetException e) {
                        e.printStackTrace();
                    }
                }

            }

        }
    }

    public Object getBean(String beanName) throws NoSuchBeanException {
        //map
        if (!beanDefinitionMap.containsKey(beanName)) {
            throw new NoSuchBeanException();
        } else {
            BeanDefinition beanDefinition = beanDefinitionMap.get(beanName);
            if (beanDefinition.getScope().equals("Singleton")) {
                //单例池开始
                Object bean = singletonObjects.get(beanName);
                if (bean == null) {
                    bean = createBean(beanDefinition);
                    singletonObjects.put(beanName, bean);
                }
                return bean;
            } else {
                //原型对象开始创建
                return createBean(beanDefinition);
            }
        }
    }

    private Object createBean(BeanDefinition beanDefinition) {
        Class beanClass = beanDefinition.getBeanClass();
        try {
            Object instance = beanClass.getDeclaredConstructor().newInstance();
            //填充属性
            for (Field field : beanClass.getDeclaredFields()) {
                if (field.isAnnotationPresent(Autowired.class)) {
                    //先byType,再byName，这里只写了byName,实际上是把所有这个类型的bean找出来，再按照名字给出
                    Object bean = getBean(field.getName());
                    field.setAccessible(true);
                    field.set(instance, bean);
                }
            }
            if (instance instanceof BeanNameAware) {
                ((BeanNameAware) instance).setBeanName(beanDefinition.getBeanName());
            }
            if (instance instanceof InitializingBean) {
                ((InitializingBean) instance).afterPropertiesSet();
            }
            for (BeanPostProcessor beanPostProcessor : beanPostProcessorSet) {
                beanPostProcessor.postProcessAfterInitialization(beanClass, instance);
            }
            return instance;
        } catch (InstantiationException | IllegalAccessException | InvocationTargetException | NoSuchMethodException | NoSuchBeanException e) {
            e.printStackTrace();
        }
        return null;
    }


}
