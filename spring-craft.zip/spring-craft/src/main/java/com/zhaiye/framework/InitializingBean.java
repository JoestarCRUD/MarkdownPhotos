package com.zhaiye.framework;

public interface InitializingBean {
    void afterPropertiesSet();
}
