package com.zhaiye.framework;

public interface BeanNameAware {
    void setBeanName(String name);
}
