package com.zhaiye;


import com.zhaiye.framework.annotation.ComponentScan;

@ComponentScan("com.zhaiye.service")
public class AppConfig {
}
