package com.zhaiye.service;

import com.zhaiye.framework.BeanPostProcessor;
import com.zhaiye.framework.annotation.Component;

@Component
public class AutowiredAnnotationBeanPostProcessor implements BeanPostProcessor {

    @Override
    public void postProcessAfterInitialization(Class beanClass, Object instance) {

        System.out.println("自动注入后置处理器");
    }
}
