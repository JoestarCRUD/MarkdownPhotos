package com.zhaiye.service;

import com.zhaiye.framework.BeanNameAware;
import com.zhaiye.framework.InitializingBean;
import com.zhaiye.framework.annotation.Autowired;
import com.zhaiye.framework.annotation.Component;

@Component("userService")
public class UserService implements BeanNameAware, InitializingBean {

    @Autowired
    private OrderService orderService;

    private String beanName;
    public void test() {
        System.out.println(orderService);
        System.out.println(beanName);
    }

    @Override
    public void setBeanName(String name) {
        this.beanName = name;
    }

    @Override
    public void afterPropertiesSet() {

    }
}
