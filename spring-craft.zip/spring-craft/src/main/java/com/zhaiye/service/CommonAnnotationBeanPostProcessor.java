package com.zhaiye.service;

import com.zhaiye.framework.BeanPostProcessor;
import com.zhaiye.framework.annotation.Component;

@Component
public class CommonAnnotationBeanPostProcessor implements BeanPostProcessor {

    @Override
    public void postProcessAfterInitialization(Class beanClass, Object instance) {
        System.out.println("Resource后置处理器");
    }
}
