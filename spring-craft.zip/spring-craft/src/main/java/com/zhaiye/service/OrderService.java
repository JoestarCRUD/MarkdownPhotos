package com.zhaiye.service;

import com.zhaiye.framework.annotation.Component;
import com.zhaiye.framework.annotation.Scope;

@Component("orderService")
@Scope("prototype")
public class OrderService {
}
